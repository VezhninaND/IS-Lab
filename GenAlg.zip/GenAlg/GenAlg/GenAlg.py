import random
population = []
for i in range(6):
    a = random.randint(0, 256)
    b = random.randint(0, 256)
    c = random.randint(0, 256)
    population.append([a, b, c])
print(population)

def fit(individual):
    return 1 / (abs(individual[0] - 96) + abs(individual[1] - 96) + abs(individual[2] - 159))

population_fitness = []
for i in range(len(population)):
    fitness = fit(population[i])
    population_fitness.append(fitness)
    print("Fitness of individual #", i, "equals:", fitness)
fitness_prob = []
for i in range(len(population_fitness)):
    prob = population_fitness[i]/sum(population_fitness)
    fitness_prob.append(prob)
    print('Probability of crossing for individual #', i, 'equals:', prob)

def roulette_wheel_pop(population, probabilities, number):
    chosen = []
    for n in range(number):
        r = random.random()
        prob_circle = 0
        for i in range(len(probabilities)):
            prob_circle += probabilities[i]
            if r <= prob_circle:
                chosen.append(population[i])
                break
    return chosen     

def to_binary(individual):
    return "{0:b}".format(individual[0]).zfill(8) + "{0:b}".format(individual[1]).zfill(8) + "{0:b}".format(individual[2]).zfill(8)

def to_decimal(individual):
    x = individual[8:]
    return [int(individual[:8], 2), int(x[:8], 2), int(individual[16:], 2)]

def pop_to_binary(population):
    binary_pop = []
    for individual in population:
        binary_pop.append(to_binary(individual))
    return binary_pop

def pop_to_decimal(population):
    decimal_pop = []
    for individual in population:
        decimal_pop.append(to_decimal(individual))
    return decimal_pop

def get_uniq_individual(population):
    new_population = []
    for elem in population:
        if elem not in new_population:
            new_population.append(elem)
    return new_population

def crossover(parent_1, parent_2):
    x = random.randint(1, len(parent_1) - 1)
    return parent_1[:x] + parent_2[x:]

def mutation(individual):
    Pm = 1/len(individual)
    result = ''
    for digit in individual:
        if (random.random() < Pm):
           result += '1' if digit == '0' else '0'
        else:
            result += digit
    return result

def population_crossover(population):
    new_pop = []
    for i in range(0, len(population), 2):
        if 0.9 > random.random():
            new_pop.append(mutation(crossover(population[i], population[i+1])))
            new_pop.append(mutation(crossover(population[i+1],population[i])))
        else:
            new_pop.append(population[i])
            new_pop.append(population[i+1])
    return new_pop

test = 0

for j in range(10000):
    population_fitness = []
    for i in range(len(population)):
        fitness = fit(population[i])
        population_fitness.append(fitness)
    fitness_prob = []
    for i in range(len(population_fitness)):
        prob = population_fitness[i]/sum(population_fitness)
        fitness_prob.append(prob)
    population_for_crossover = roulette_wheel_pop(population, fitness_prob, 6)
    binary_population_for_crossover = pop_to_binary(population_for_crossover)
    new_population = population_crossover(binary_population_for_crossover)
    population_for_crossover = get_uniq_individual(population_for_crossover)
    new_population = pop_to_decimal(new_population)
    try:
         new_population.sort(key=fit, reverse = True)
         population = new_population
    except ZeroDivisionError:
        print('Last population # ', j, ':')
        print(new_population)
        for i in range(len(new_population)):
            print('Objective function of individual #', i, 'equals:', abs(population[i][0] - 96) + abs(population[i][1] - 96) + abs(population[i][2] - 159))
        break
    for i in range(len(population)):
        if fit(population[i]) >= 1:
            test = 1
            print('Last population # ', j, ':')
            print(new_population)
            for i in range(len(new_population)):
                print('Objective function of individual #', i, 'equals:', abs(population[i][0] - 96) + abs(population[i][1] - 96) + abs(population[i][2] - 159))
            break
    if test == 1:
        break